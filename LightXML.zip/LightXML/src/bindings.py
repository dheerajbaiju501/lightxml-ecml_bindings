import pathlib
import torch
from typing import Any, Optional

#module_path = pathlib.Path(__file__).parent.resolve()
#library_path = module_path / "libtorch_sparse_ops.so"
#torch.ops.load_library(library_path)
#torch_sparse_ops = torch.ops.torch_sparse_ops


class SparseHingeLossFunction(torch.autograd.Function):
    # noinspection PyMethodOverriding
    @staticmethod
    def forward(ctx: Any,
                scores: torch.Tensor,
                labels: torch.Tensor) -> torch.Tensor:
        ctx.save_for_backward(scores, labels)
        result = torch_sparse_ops.squared_hinge_forward(scores, labels)
        return result

    # noinspection PyMethodOverriding
    @staticmethod
    def backward(ctx, grad_output: torch.Tensor):
        scores, labels = ctx.saved_tensors
        grad_output = grad_output.contiguous()
        scores_grad = torch_sparse_ops.squared_hinge_backward(scores, labels, grad_output)

        return scores_grad, None


class FFIMulFunction(torch.autograd.Function):
    # noinspection PyMethodOverriding
    @staticmethod
    @torch.cuda.amp.custom_fwd
    def forward(ctx: Any,
                features: torch.Tensor,
                weights: torch.Tensor,
                locations: torch.Tensor,
                bias: Optional[torch.Tensor],
                transpose: bool = True,
                strategy: int = -1) -> torch.Tensor:
        ctx.transpose = transpose

        if transpose:
            features = torch.transpose(features, 0, 1).contiguous()
        else:
            features = features.contiguous()

        ctx.save_for_backward(features, weights, locations)
        result = torch_sparse_ops.ffi_forward(features, weights, locations, bias, transpose, strategy)

        if bias is not None:
            ctx.use_bias = True
        else:
            ctx.use_bias = False
        return result

    # noinspection PyMethodOverriding
    @staticmethod
    @torch.cuda.amp.custom_bwd
    def backward(ctx, grad_output):
        features, weights, locations, = ctx.saved_tensors
        transpose = ctx.transpose

        grad_output = grad_output.contiguous()

        if ctx.use_bias:
            bias_gradient = torch.sum(grad_output, dim=0).detach()
        else:
            bias_gradient = None

        input_gradient = torch_sparse_ops.ffi_backward_ftr(
            features, weights, locations, grad_output, transpose
        )

        weight_gradient = torch_sparse_ops.ffi_backward_wgt(
            features, weights, locations, grad_output, transpose
        )

        if transpose:
            input_gradient = torch.transpose(input_gradient, 0, 1)

        return input_gradient, weight_gradient, None, bias_gradient, None, None, None
