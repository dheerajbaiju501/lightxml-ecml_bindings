import torch
from torch import nn
from transformers import BertModel
from transformers import BertTokenizer, BertConfig, BertModel
from bindings import SparseHingeLossFunction  # Importing CUDA-based custom loss function
from apex import amp

def get_bert(bert_name):
    if 'roberta' in bert_name:
        print('load roberta-base')
        model_config = RobertaConfig.from_pretrained('roberta-base')
        model_config.output_hidden_states = True
        bert = RobertaModel.from_pretrained('roberta-base', config=model_config)
    elif 'xlnet' in bert_name:
        print('load xlnet-base-cased')
        model_config = XLNetConfig.from_pretrained('xlnet-base-cased')
        model_config.output_hidden_states = True
        bert = XLNetModel.from_pretrained('xlnet-base-cased', config=model_config)
    else:
        print('load bert-base-uncased')
        model_config = BertConfig.from_pretrained('bert-base-uncased')
        model_config.output_hidden_states = True
        bert = BertModel.from_pretrained('bert-base-uncased', config=model_config)
    return bert

class LightXML(nn.Module):
    def __init__(self, n_labels, bert='bert-base', dropout=0.5):
        super(LightXML, self).__init__()
        self.n_labels = n_labels
        self.bert = BertModel.from_pretrained('bert-base-cased')
        self.dropout = nn.Dropout(dropout)
        self.classifier = nn.Linear(self.bert.config.hidden_size, n_labels)

    def forward(self, input_ids, attention_mask, token_type_ids):
        # Forward pass with BERT
        bert_outputs = self.bert(input_ids, attention_mask, token_type_ids)
        pooled_output = bert_outputs.pooler_output
        pooled_output = self.dropout(pooled_output)

        # Classification layer
        logits = self.classifier(pooled_output)
        return logits

    def compute_loss(self, logits, labels, use_sparse_loss=False):
        if use_sparse_loss:
            # Use CUDA-optimized sparse hinge loss
            loss = SparseHingeLossFunction.apply(logits, labels)
        else:
            # Default loss (e.g., CrossEntropy)
            loss_fn = nn.CrossEntropyLoss()
            loss = loss_fn(logits, labels)
        return loss

    def get_tokenizer(self):
        #if 'roberta' in self.bert_name:
         #   print('load roberta-base tokenizer')
          #  tokenizer = RobertaTokenizer.from_pretrained('roberta-base', do_lower_case=True)
        #elif 'xlnet' in self.bert_name:
         #   print('load xlnet-base-cased tokenizer')
          #  tokenizer = XLNetTokenizer.from_pretrained('xlnet-base-cased')
        #else:
        print('load bert-base-uncased tokenizer')
        tokenizer = BertTokenizer.from_pretrained('bert-base-uncased', do_lower_case=True)
        return tokenizer

    def one_epoch(self, dataloader, optimizer, mode="train", use_sparse_loss=False):
        self.train() if mode == "train" else self.eval()
        total_loss = 0

        for batch in dataloader:
            input_ids, attention_mask, token_type_ids, labels = (
                batch["input_ids"],
                batch["attention_mask"],
                batch["token_type_ids"],
                batch["labels"],
            )

            optimizer.zero_grad()
            logits = self.forward(input_ids, attention_mask, token_type_ids)
            loss = self.compute_loss(logits, labels, use_sparse_loss)

            if mode == "train":
                loss.backward()
                optimizer.step()

            total_loss += loss.item()
        return total_loss / len(dataloader)
