import torch
from transformers import AdamW
from torch.utils.data import DataLoader

from model import LightXML
from dataset import MDataset  # Assuming this handles dataset preparation


def train(model, dataloader, optimizer, use_sparse_loss=False):
    print("Starting training with Sparse Hinge Loss" if use_sparse_loss else "Starting training with default loss")

    for epoch in range(10):  # Example: 10 epochs
        train_loss = model.one_epoch(dataloader, optimizer, mode="train", use_sparse_loss=use_sparse_loss)
        print(f"Epoch {epoch + 1} - Loss: {train_loss:.4f}")


def main():
    # Example configuration
    n_labels = 1000  # Replace with actual number of labels
    batch_size = 32

    # Initialize model
    model = LightXML(n_labels)

    # Prepare dataset and dataloader
    dataset = MDataset()  # Assumes MDataset is implemented correctly
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

    # Optimizer
    optimizer = AdamW(model.parameters(), lr=5e-5)

    # Train model
    train(model, dataloader, optimizer, use_sparse_loss=True)


if __name__ == "__main__":
    main()
