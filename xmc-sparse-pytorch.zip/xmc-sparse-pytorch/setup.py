import os
from skbuild import setup  # This line replaces 'from setuptools import setup'


def make_pkgdir_mapping():
    mapping = {'torch_sparse': 'src/python'}
    return mapping


def should_exclude(name: str):
    return name.endswith('.a') or name.endswith('.cmake') or name.endswith(".hpp") or "include/experimental" in name


def exclude_files(cmake_manifest):
    return list(filter(lambda name: not should_exclude(name), cmake_manifest))


pkgdir_mapping = make_pkgdir_mapping()

version = "0.0.6"
# potentially add a development version suffix
if "XCK_PT_DEV_SUFFIX" in os.environ:
    version = version + ".dev" + os.environ["XCK_PT_DEV_SUFFIX"]

# potentially add a local version suffix to the version number
if "XCK_PT_VERSION_SUFFIX" in os.environ:
    version = version + "+" + os.environ["XCK_PT_VERSION_SUFFIX"]

torch_version = "torch==2.0.*"
if "XCK_PT_TORCH_VERSION" in os.environ:
    torch_version = f'torch=={os.environ["XCK_PT_TORCH_VERSION"]}.*'

setup(
    cmake_args=["-DCMAKE_BUILD_TYPE=RelWithDebInfo"],
    name="torch_sparse",
    version=version,
    description="Sparse operations for extreme classification in pyTorch",
    author='Jarno Rantaharju',
    license="MIT",
    packages=pkgdir_mapping.keys(),
    package_dir=pkgdir_mapping,
    python_requires=">=3.8",
    install_requires=["numpy", torch_version],
    setup_requires=[torch_version],
    cmake_process_manifest_hook=exclude_files,
    cmake_languages=("C", "CXX", "CUDA")
)
