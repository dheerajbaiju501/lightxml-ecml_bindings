import pytest
import torch

if torch.cuda.is_available():
    devices = ["cuda", "cpu"]
else:
    devices = ["cpu"]


@pytest.mark.parametrize("device", devices)
def test_basics(device):
    """
    This test just imports and runs the rewire layer. It doesn't actually test any outputs; it just makes sure that
    things run.
    """
    from torch_sparse.rewire import FixedFanIn

    batch_size = 4
    in_size = 67

    layer = FixedFanIn(in_size, 175, 16, rewire_threshold=0.1).to(device)
    inputs = torch.zeros((batch_size, in_size)).to(device)

    output = layer(inputs)

    layer.rewire()


@pytest.mark.parametrize("device", devices)
def test_compile(device):
    """
    This test checks that FixedFanIn can use pytorch's compile api
    """
    from torch_sparse.rewire import FixedFanIn

    batch_size = 4
    in_size = 67

    layer = FixedFanIn(in_size, 175, 16, rewire_threshold=0.1).to(device)
    forward = torch.compile(layer)
    inputs = torch.zeros((batch_size, in_size)).to(device)

    output = forward(inputs)

    layer.rewire()
