import pytest
import torch

from torch_sparse import ops

if torch.cuda.is_available():
    devices = ["cuda", "cpu"]
else:
    devices = ["cpu"]


@pytest.mark.parametrize("device", devices)
@pytest.mark.parametrize("transpose", [False, True])
def test_multi_dim(device, transpose):
    """
    Tests that multi-dimensional input is correctly broadcasted.
    """
    batch_size = 30
    seq_len = 6
    feature_size = 165
    output_size = 503
    fan_in = 17

    features = torch.randn(batch_size, seq_len, feature_size, dtype=torch.float32, requires_grad=True, device=device)
    weights = torch.randn(output_size, fan_in, dtype=torch.float32, requires_grad=True, device=device)
    locations = torch.randint(0, feature_size, (output_size, fan_in), dtype=torch.int32, requires_grad=False,
                              device=device)

    # do the multiplication jointly
    all_results = ops.ffi_mul(features, weights, locations, None, transpose)
    assert all_results.shape == (batch_size, seq_len, output_size)

    # and compare result with slices
    one_result = ops.ffi_mul(features[:, 5, :], weights, locations, None, transpose)
    assert (all_results[:, 5, :] == one_result).all()

    one_result = ops.ffi_mul(features[8, :, :], weights, locations, None, transpose)
    assert (all_results[8, :, :] == one_result).all()


@pytest.mark.parametrize("device", devices)
@pytest.mark.parametrize("transpose", [False, True])
def test_int16(device, transpose):
    """
    Test that int16 and int32 indices give the same result.
    """
    batch_size = 30
    feature_size = 165
    output_size = 503
    fan_in = 17

    features = torch.randn(batch_size, feature_size, dtype=torch.float32, requires_grad=True, device=device)
    weights = torch.randn(output_size, fan_in, dtype=torch.float32, requires_grad=True, device=device)
    locations = torch.randint(0, feature_size, (output_size, fan_in), dtype=torch.int16, requires_grad=False,
                              device=device)

    int16_result = ops.ffi_mul(features, weights, locations.to(torch.int16), None, transpose)
    int32_result = ops.ffi_mul(features, weights, locations.to(torch.int32), None, transpose)
    assert (int16_result == int32_result).all()


def _run_ffi_backward(features, weights, locations, out_grad, transpose):
    """
    Helper function to run only the backward pass.
    """
    from torch_sparse.bindings import torch_sparse_ops as raw_ops
    if transpose:
        return (raw_ops.ffi_backward_ftr(features, weights, locations, out_grad, True),
                raw_ops.ffi_backward_wgt(features, weights, locations, out_grad, True))
    else:
        return (raw_ops.ffi_backward_ftr(features, weights, locations, out_grad, False),
                raw_ops.ffi_backward_wg(features, weights, locations, out_grad, False))


@pytest.mark.parametrize("device", devices)
@pytest.mark.parametrize("transpose", [False, True])
def test_shapes(device, transpose):
    """
    Validate shapes and shape checking: We should get a ValueError if
    shapes are incompatible.
    """
    batch_size = 30
    feature_size = 165
    output_size = 503
    fan_in = 17

    features = torch.randn(batch_size, feature_size, dtype=torch.float32, requires_grad=True, device=device)
    features_w = torch.randn((batch_size + 1), feature_size, dtype=torch.float32, requires_grad=True, device=device)
    bias = torch.randn(output_size, dtype=torch.float32, requires_grad=True, device=device)
    bias_w = torch.randn(output_size + 1, dtype=torch.float32, requires_grad=True, device=device)
    weights = torch.randn(output_size, fan_in, dtype=torch.float32, requires_grad=True, device=device)
    weights_w = torch.randn(output_size + 1, fan_in, dtype=torch.float32, requires_grad=True,
                            device=device)
    locations = torch.randint(0, feature_size, (output_size, fan_in), dtype=torch.int16, requires_grad=False,
                              device=device)
    locations_w = torch.randint(0, feature_size, (output_size, fan_in-1), dtype=torch.int32,
                                requires_grad=False, device=device)

    result = ops.ffi_mul(features, weights, locations, bias, transpose)
    assert result.shape[0] == batch_size
    assert result.shape[1] == output_size

    # input wrongly shaped values to trigger a ValueError:
    # note: we cannot check feature-size by inspecting shapes, so wrong feature_size can currently lead to a crash.
    with pytest.raises(ValueError):
        ops.ffi_mul(features, weights_w, locations, bias, transpose)

    with pytest.raises(ValueError):
        ops.ffi_mul(features, weights, locations_w, bias, transpose)

    with pytest.raises(ValueError):
        ops.ffi_mul(features, weights, locations, bias_w, transpose)

    # explicitly call the backward op
    out_grad = torch.randn(batch_size, output_size, dtype=torch.float32, requires_grad=True, device=device)
    out_grad_w = torch.randn(batch_size, output_size-1, dtype=torch.float32, requires_grad=True, device=device)
    with pytest.raises(ValueError):
        _run_ffi_backward(features, weights_w, locations, out_grad, transpose)

    with pytest.raises(ValueError):
        _run_ffi_backward(features, weights, locations_w, out_grad, transpose)

    # note: we cannot detect wrong feature-size, but we can detect wrong batch size
    with pytest.raises(ValueError):
        _run_ffi_backward(features_w, weights, locations, out_grad, transpose)

    with pytest.raises(ValueError):
        _run_ffi_backward(features, weights, locations, out_grad_w, transpose)


@pytest.mark.parametrize("strategy", [2, 3, 4, 5, 6, 7, 8, 9, 10])
@pytest.mark.parametrize("transpose", [False, True])
@pytest.mark.parametrize("has_bias", [False, True])
def test_explicit_strategy(strategy, transpose: bool, has_bias: bool):
    if not torch.cuda.is_available():
        return

    batch_size = 30
    feature_size = 165
    output_size = 503
    fan_in = 24

    features = torch.randn(batch_size, feature_size, dtype=torch.float32, requires_grad=True, device="cuda")
    weights = torch.randn(output_size, fan_in, dtype=torch.float32, requires_grad=True, device="cuda")
    locations = torch.randint(0, feature_size, (output_size, fan_in), dtype=torch.int32, requires_grad=False,
                              device="cuda")
    if has_bias:
        bias = torch.randn(output_size, dtype=torch.float32, requires_grad=True, device="cuda")
    else:
        bias = None

    result_a = ops.ffi_mul(features, weights, locations, bias, transpose, strategy=strategy)
    result_b = ops.ffi_mul(features, weights, locations, bias, transpose,
                           strategy=ops.FFIStrategies.GPU_UnitBatch_Fan)
    assert torch.allclose(result_a, result_b, rtol=1e-5, atol=1e-5)


@pytest.mark.parametrize("transpose", [False, True])
@pytest.mark.parametrize("has_bias", [False, True])
def test_fp16(transpose: bool, has_bias: bool):
    batch_size = 30
    feature_size = 165
    output_size = 503
    fan_in = 24

    features = torch.randn(batch_size, feature_size, dtype=torch.float16, device="cuda")
    weights = torch.randn(output_size, fan_in, dtype=torch.float16, device="cuda")
    locations = torch.randint(0, feature_size, (output_size, fan_in), dtype=torch.int32, device="cuda")

    if has_bias:
        bias = torch.randn(output_size, dtype=torch.float16, device="cuda")
    else:
        bias = None

    result_a = ops.ffi_mul(features, weights, locations, bias, transpose)
    result_b = ops.ffi_mul(features.to(torch.float32), weights.to(torch.float32), locations,
                           bias.to(torch.float32) if bias is not None else None, transpose)

    assert torch.allclose(result_a.to(torch.float32), result_b, rtol=1e-3, atol=1e-3)


@pytest.mark.parametrize("transpose", [False, True])
@pytest.mark.parametrize("has_bias", [False, True])
def test_autocast(transpose: bool, has_bias: bool):
    batch_size = 30
    feature_size = 165
    output_size = 503
    fan_in = 24

    features = torch.randn(batch_size, feature_size, dtype=torch.float32, requires_grad=True, device="cuda")
    weights = torch.randn(output_size, fan_in, dtype=torch.float32, requires_grad=True, device="cuda")
    locations = torch.randint(0, feature_size, (output_size, fan_in), dtype=torch.int32, device="cuda")

    if has_bias:
        bias = torch.randn(output_size, dtype=torch.float32, requires_grad=True, device="cuda")
    else:
        bias = None

    with torch.autocast(device_type="cuda", enabled=True):
        result = ops.ffi_mul(features, weights, locations, bias, transpose)

    result.sum().backward()

    assert result.dtype == torch.float16
