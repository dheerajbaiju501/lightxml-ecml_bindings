import pytest
import torch
from torch.autograd import gradcheck
from torch_sparse import ops

if torch.cuda.is_available():
    devices = ["cuda", "cpu"]
else:
    devices = ["cpu"]


@pytest.mark.parametrize("transpose", [True, False])
@pytest.mark.parametrize("bias", [True, False])
@pytest.mark.parametrize("device", devices)
def test_grad_ffi(transpose, bias, device):
    batch_size = 30
    feature_size = 165
    output_size = 503
    fan_in = 17

    features = torch.randn(batch_size, feature_size, dtype=torch.float32, requires_grad=True, device=device)
    weights = torch.randn(output_size, fan_in, dtype=torch.float32, requires_grad=True, device=device)
    locations = torch.randint(0, feature_size, (output_size, fan_in), dtype=torch.int32, requires_grad=False,
                              device=device)
    if bias:
        bias = torch.randn(output_size, dtype=torch.float32, requires_grad=True, device=device)
    else:
        bias = None
    # TODO what should be the tolerances here?
    # TODO for some reason, fast mode passes, but slow mode doesn't
    # TODO implement double kernels for these checks.
    test = gradcheck(ops.ffi_mul, (features, weights, locations, bias, transpose), eps=1e-4, atol=1e-5, rtol=1e-3,
                     fast_mode=True, nondet_tol=1e-5)


@pytest.mark.parametrize("device", devices)
def test_grad_squared_hinge(device):
    batch_size = 30
    output_size = 503
    num_labels = 1067
    scores = torch.randn(batch_size, output_size, dtype=torch.float32, requires_grad=True, device=device)
    positives_batch = torch.randint(0, batch_size, (num_labels,),
                                    dtype=torch.int32, requires_grad=False, device=device)
    positives_label = torch.randint(0, output_size, (num_labels,),
                                    dtype=torch.int32, requires_grad=False, device=device)
    positives = torch.stack([positives_batch, positives_label], dim=-1)

    test = gradcheck(ops.sparse_hinge_loss, (scores, positives), eps=1e-5, atol=1e-5, rtol=1e-3, fast_mode=True)
