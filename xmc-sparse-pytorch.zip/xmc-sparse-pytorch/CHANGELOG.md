# Version 0.0.7
* Drop support for pytorch 2.0 and 11.7.
* Deprecate support for pytorch 2.1 and pytorch 2.2 (no longer built by default, but CI allows manual build)
* add support for pytorch 2.4, enable ADA and HOPPER for Cuda 12.1 builds

# Version 0.0.6
* Allow selecting different pruning modes
* Allow selecting which implementation to use for the forward kernel
* Updated xmc-kernels version
* add support for pytorch 2.3 / cuda 12.1

# Version 0.0.5
* Updated xmc-kernels version to get important fixes for gradient kernels
* Added meta-device versions to make things compatible with `torch.compile`
* Option to initialize regrown weights with zeros
* Also build for pytorch 2.1 and 2.2
* Small fixes

# Version 0.0.4
* Update kernels
* manylinux compatible wheels
* broadcast ffi matmul to dim>=2 inputs
* added support for 16-bit indices

# Version 0.0.3
* Handle bias as part of the kernel calls
