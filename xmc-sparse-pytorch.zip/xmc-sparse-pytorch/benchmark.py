import torch
import numpy as np
from torch_sparse.rewire import rewire
from torch.utils import benchmark

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

torch.manual_seed(1)


def forward_run(model, input):
    return model(input)


def forward_and_backward_run(model, input):
    x = model(input)
    loss = torch.mean(x)
    loss.backward()
    return model.weights.grad, model.bias.grad


sparse = rewire(128, 1000, sparsity=0.1).to(device)
input = np.random.rand(100, 128)
input = torch.tensor(input, dtype=torch.float, requires_grad=True, device=device)

t0 = benchmark.Timer(
    stmt='forward_run(sparse, input)',
    setup='from __main__ import forward_run',
    globals={'sparse': sparse, 'input': input})

t1 = benchmark.Timer(
    stmt='forward_and_backward_run(sparse, input)',
    setup='from __main__ import forward_and_backward_run',
    globals={'sparse': sparse, 'input': input})

print(t0.timeit(20))
print(t1.timeit(10))
