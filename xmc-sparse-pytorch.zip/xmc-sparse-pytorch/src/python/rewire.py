import torch
import math
from . import ops

GROWTH_MODES = ['random']  # [ 'random','momentum', 'momentum_neuron', 'gradient']
PRUNE_MODES = ['threshold', 'fraction']
INIT_MODES = ["random", "zero"]


# pytorch provides `unravel_index` only starting with version 2.2
# we use this if it is available, and provide a backport of this function otherwise.
if hasattr(torch, 'unravel_index'):
    unravel_function = torch.unravel_index
else:
    import itertools
    import operator

    def unravel_index_old(indices, shape):
        if indices.is_complex() or indices.is_floating_point() or indices.dtype == torch.bool:
            raise TypeError(f"Expected 'indices' to be an integer tensor, but got {indices.dtype}")

        if not all(dim >= 0 for dim in shape):
            raise ValueError(f"'shape' cannot have negative values, but got {tuple(shape)}")

        # unravel implementation based on pytorch 2.2's code
        coefs = list(reversed(list(itertools.accumulate(reversed(shape[1:] + torch.Size([1])), func=operator.mul))))
        combined = indices.unsqueeze(-1).floor_divide(
            torch.tensor(coefs, device=indices.device, dtype=torch.int64)
        ) % torch.tensor(shape, device=indices.device, dtype=torch.int64)
        return combined.unbind(-1)

    unravel_function = unravel_index_old


class FixedFanIn(torch.nn.Module):
    '''
    Implements a fixed fan-in sparse linear layer for PyTorch models.

    This layer preserves a constant number of incoming connections (fan-in) per output neuron,
    offering dynamic adjustments through pruning and regrowth strategies based on the layer's
    configuration. Supports customizable pruning modes, growth modes, and weight initialization methods.

    Args:
        in_features (int): Number of input features.
        out_features (int): Number of output features.
        fan_in (int): Number of incoming connections per output neuron.
        bias (bool, optional): Whether to include a bias term. Defaults to ``True``.
        device, dtype: Specifications for the device and data type of the module's parameters.
        transpose (bool, optional): Whether the feature matrix should be transposed. Defaults to True.
        prune_mode (str, optional): Strategy for pruning weights ('threshold' or 'fraction'). Defaults to 'threshold'.
        rewire_threshold (float, optional): Threshold for pruning in 'threshold' mode. Must be specified if using this mode.
        rewire_fraction (float, optional): Fraction of weights to prune in 'fraction' mode. Must be specified if using this mode.
        growth_mode (str, optional): Strategy for adding new weights during the rewire process. Defaults to 'random'.
        init_mode (str, optional): Method for initializing new weights ('random' or 'zero'). Defaults to 'random'.
        strategy (int, optional): Which kernel implementation to use. Can be tuned for improved performance.

    '''
    __constants__ = ['in_features', 'out_features', 'fan_in']
    in_features: int
    out_features: int
    fan_in: int

    def __init__(
            self,
            in_features: int, out_features: int,
            fan_in: int,
            bias: bool = True,
            device=None,
            dtype=None,
            *,
            transpose=True,
            prune_mode="threshold",
            rewire_threshold=None,
            rewire_fraction=None,
            growth_mode="random",
            init_mode="random",
            strategy=-1,
            **kwargs
    ):
        super().__init__(**kwargs)
        factory_kwargs = {'device': device, 'dtype': dtype}

        self.in_features = in_features
        self.output_features = out_features
        self.fan_in = fan_in
        self.transpose = transpose
        self.strategy = strategy

        # validation for different modes and their parameters.
        assert prune_mode in PRUNE_MODES, f"Invalid prune_mode={prune_mode}; supported: {PRUNE_MODES}"
        assert growth_mode in GROWTH_MODES, f"Invalid growth_mode={growth_mode}; supported: {GROWTH_MODES}"
        assert init_mode in INIT_MODES, f"Invalid init_mode={init_mode}; supported: {INIT_MODES}"

        if prune_mode == "threshold" and rewire_threshold is None:
            raise ValueError("rewire_threshold must be specified for prune_mode 'threshold'")
        elif prune_mode == "fraction" and rewire_fraction is None:
            raise ValueError("rewire_fraction must be specified for prune_mode 'fraction'")

        self.prune_mode = prune_mode
        self.growth_mode = growth_mode
        self.init_mode = init_mode

        # assignment and verification of pruning parameters.
        if prune_mode == 'fraction':
            self.rewire_fraction = rewire_fraction
            assert rewire_fraction >= 0 and rewire_fraction < 1, f"Invalid reware_fraction={rewire_fraction}; supported range [0,1)"
        elif prune_mode == 'threshold':
            self.rewire_threshold = rewire_threshold

        weights = torch.empty((out_features, fan_in), **factory_kwargs)
        self.weights = torch.nn.parameter.Parameter(weights)
        bound = 1 / math.sqrt(self.fan_in)
        torch.nn.init.uniform_(self.weights, -bound, bound)

        if bias:
            self.bias = torch.nn.parameter.Parameter(torch.empty(out_features, **factory_kwargs))
            torch.nn.init.zeros_(self.bias)
        else:
            self.register_parameter('bias', None)

        if self.in_features < 32_768:
            locations = torch.randint(high=self.in_features, size=(out_features, fan_in), dtype=torch.int16)
        else:
            locations = torch.randint(high=self.in_features, size=(out_features, fan_in), dtype=torch.int32)
        self.register_buffer("locations", locations, persistent=True)

    def rewire(self):
        with torch.no_grad():
            # make new connections
            if self.prune_mode == 'threshold':
                update_loc = torch.where(torch.abs(self.weights) < self.rewire_threshold)
            elif self.prune_mode == 'fraction':
                num_selected = int(self.output_features * self.fan_in * self.rewire_fraction)
                _, ind = torch.topk(torch.abs(self.weights.flatten()), k=num_selected, largest=False, sorted=False)
                update_loc = unravel_function(ind, self.weights.shape)

            self.locations[update_loc] = torch.randint(high=self.in_features, size=update_loc[0].shape,
                                                       dtype=self.locations.dtype, device=self.locations.device)

            # initialize newly-grown connections
            regrowth = torch.empty(size=update_loc[0].shape, device=self.weights.device)
            if self.init_mode == "random":
                bound = 1 / math.sqrt(self.fan_in)
                regrowth.uniform_(-bound, bound)
            else:
                regrowth.zero_()
            self.weights[update_loc] = regrowth

    def forward(self, features):
        result = ops.ffi_mul(
            features, self.weights, self.locations, self.bias, self.transpose, strategy=self.strategy
        )
        return result

    def extra_repr(self) -> str:
        return 'in_features={}, out_features={}, fan_in={}, bias={}'.format(
            self.in_features, self.out_features, self.fan_in, self.bias is not None
        )
