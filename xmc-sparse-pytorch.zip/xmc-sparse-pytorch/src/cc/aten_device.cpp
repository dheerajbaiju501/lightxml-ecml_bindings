// Copyright (c) 2023, Aalto University, developed by Erik Schultheis
// All rights reserved.
//
// SPDX-License-Identifier: MIT


#include "ATen/Parallel.h"
#include "device.h"

void TorchThreadDevice::parallel(std::int64_t n, CostData cost, std::function<void(std::int64_t, std::int64_t)> f) {
    at::parallel_for(0, n, grain_size(n, cost), f);
}

/// Computation of the chunk size used for parallelization -- taken from Eigen.
std::int64_t TorchThreadDevice::grain_size(std::int64_t n, CostData cost) {
    // Scaling from Eigen compute cost to device cycles.
    constexpr const int kDeviceCyclesPerComputeCycle = 1;

    // Costs in device cycles.
    constexpr const int kTaskSize = 40000;

    constexpr const double kLoadCycles = 1.0 / 64 * 11;
    constexpr const double kStoreCycles = 1.0 / 64 * 11;

    // Scaling from Eigen compute cost to device cycles.
    double total_cost = kLoadCycles * cost.BytesLoaded + kStoreCycles * cost.BytesStored + kDeviceCyclesPerComputeCycle * cost.ComputeCycles;

    const auto block_size = static_cast<std::int64_t>(kTaskSize / total_cost);
    constexpr const int max_oversharding_factor = 4;
    const std::int64_t bound = at::divup(n, max_oversharding_factor * at::get_num_threads());
    return std::min(n, std::max(bound, block_size));
}
