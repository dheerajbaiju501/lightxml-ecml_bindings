// Copyright (c) 2023, Aalto University, developed by Erik Schultheis
// All rights reserved.
//
// SPDX-License-Identifier: MIT

#ifndef XMC_KERNELS_PYTORCH_TORCH_SPARSE_DEVICE_H
#define XMC_KERNELS_PYTORCH_TORCH_SPARSE_DEVICE_H

#include "c10/core/DeviceType.h"
#include "xmc-kernels/device.h"

// Parallel CPU device using pytorch's backend
class TorchThreadDevice : public xck::CpuDevice {
public:
    explicit TorchThreadDevice() = default;
    void parallel(std::int64_t n, CostData cost, std::function<void(std::int64_t, std::int64_t)> f) override;

private:
    /// Computation of the chunk size used for parallelization -- taken from Eigen.
    static std::int64_t grain_size(std::int64_t n, CostData cost);
};

// Select concrete device implementation based on kernel device
namespace detail
{
using torch::DeviceType;
inline torch::DeviceType get_torch_device(xck::EDeviceType type) {
    switch (type) {
        case xck::EDeviceType::Cpu:
            return DeviceType::CPU;
        case xck::EDeviceType::Cuda:
            return DeviceType::CUDA;
        default:
            throw std::logic_error("Only CPU and CUDA devices are supported.");
    }
}

template<xck::EDeviceType Type>
struct torch_device_dispatch;

template<>
struct torch_device_dispatch<xck::EDeviceType::Cpu> {
    using type = TorchThreadDevice;
    static constexpr DeviceType device_enum = DeviceType::CPU;
};

template<>
struct torch_device_dispatch<xck::EDeviceType::Cuda> {
    using type = xck::CudaDevice;
    static constexpr DeviceType device_enum = DeviceType::CUDA;
};
}// namespace detail

template<xck::EDeviceType Type>
using torch_device_t = typename detail::torch_device_dispatch<Type>::type;

#define CHECK_DEVICE(x, Device) TORCH_CHECK_EQ(x.device().type(), detail::get_torch_device(Device));

#endif//XMC_KERNELS_PYTORCH_TORCH_SPARSE_DEVICE_H
