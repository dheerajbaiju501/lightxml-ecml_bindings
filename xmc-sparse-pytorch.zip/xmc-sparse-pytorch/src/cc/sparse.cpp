#include "device.h"
#include "xmc-kernels/detail/dispatch.h"
#include "xmc-kernels/fixed_fan_in_matmul.h"
#include "xmc-kernels/pointwise.h"
#include <ATen/Parallel.h>
#include <ATen/autocast_mode.h>
#include <cuda_fp16.h>
#include <torch/extension.h>

#if TORCH_VERSION_MAJOR < 2
#error "Torch 1.x is not supported"
#endif

using torch::Tensor;
using OptTensor = torch::optional<Tensor>;

namespace
{
// because pytorch doesn't have a uint16 dtype, we need this
// hack: Take int16 data, but interpret as uint16. This is
// completely safe and straightforward as long as only positive
// numbers are involved, as, e.g., in valid index tensors.
// similarly, we need to access half as at::Half
template<class T>
auto data_ptr(const Tensor& data) {
    return data.data_ptr<T>();
}

template<>
auto data_ptr<std::uint16_t>(const Tensor& data) {
    return reinterpret_cast<std::uint16_t*>(data.data_ptr<std::int16_t>());
}

template<>
auto data_ptr<half>(const Tensor& data) {
    return reinterpret_cast<half*>(data.data_ptr<at::Half>());
}

template<class T>
xck::MatrixData<T> to_matrix(const Tensor& data) {
    TORCH_CHECK(data.is_contiguous())
    TORCH_CHECK_EQ(data.dim(), 2);
    return std::experimental::mdspan(data_ptr<T>(data), data.size(0), data.size(1));
}

template<class T>
xck::VectorData<T> to_vector(const Tensor& data) {
    TORCH_CHECK(data.is_contiguous())
    TORCH_CHECK_EQ(data.dim(), 1);
    return std::experimental::mdspan(data_ptr<T>(data), data.size(0));
}

template<class T>
auto to_matrix(const OptTensor& data) -> decltype(std::make_optional(to_matrix<T>(data.value()))) {
    if (data.has_value()) {
        return std::make_optional(to_matrix<T>(data.value()));
    } else {
        return std::nullopt;
    }
}

template<class T>
auto to_vector(const OptTensor& data) -> decltype(std::make_optional(to_vector<T>(data.value()))) {
    if (data.has_value()) {
        return std::make_optional(to_vector<T>(data.value()));
    } else {
        return std::nullopt;
    }
}

Tensor allocate_output(const torch::Tensor& ref, std::int64_t dim0, std::int64_t dim1) {
    return at::empty({dim0, dim1}, at::device(ref.device()).dtype(ref.dtype()));
}
}// namespace

template<xck::EDeviceType Device>
struct SparseForwardOp {

    template<class Float, class Int, bool Transposed>
    static Tensor run(
            xck::ForwardImplementations strategy,
            const Tensor& features,
            const Tensor& weights,
            const Tensor& locations,
            const OptTensor& bias_opt) {
        using OP = xck::FFIMatmulOp<Float, Int, Transposed>;

        CHECK_DEVICE(features, Device)
        CHECK_DEVICE(weights, Device)
        CHECK_DEVICE(locations, Device)
        if (bias_opt.has_value()) {
            CHECK_DEVICE(bias_opt.value(), Device)
        }

        xck::EDeviceType strategy_device = xck::dispatch::get_device<OP>(strategy);
        TORCH_CHECK(strategy_device == Device, "Device mismatch");

        // TODO with improved input checking as part of OP::call, we might remove this
        TORCH_CHECK_VALUE(weights.size(0) == locations.size(0), "mismatch in number of outputs")
        TORCH_CHECK_VALUE(weights.size(1) == locations.size(1), "mismatch in fan-in")
        if (bias_opt.has_value()) {
            TORCH_CHECK_VALUE(weights.size(0) == bias_opt.value().size(0), "mismatch in number of outputs")
        }

        std::int64_t batch_size = Transposed ? features.size(1) : features.size(0);
        std::int64_t output_size = weights.size(0);

        torch_device_t<Device> device{};
        Tensor output = allocate_output(features, batch_size, output_size);

        OP::call(device, strategy,
                 to_matrix<Float>(features),
                 to_matrix<Int>(locations),
                 to_matrix<Float>(weights),
                 to_vector<Float>(bias_opt),
                 to_matrix<Float>(output));

        return output;
    }

    static xck::ForwardImplementations select_strategy(const Tensor& weights, bool transposed) {
        using Enum = xck::ForwardImplementations;
        // This is a simple heuristic to determine which kernel to select. It certainly
        // will be suboptimal in many cases, but it never should choose a kernel that is
        // worse by an order of magnitude.

        // For GPU kernels, we have vectorized versions, which generally are faster, but only
        // work when the weights form a multiple of four.
        bool can_vec = weights.size(0) % 4 == 0;
        // If the device is CPU, we only have one option
        if constexpr (Device == xck::EDeviceType::Cpu) {
            return Enum::CPU;
        } else if (transposed) {
            // For transposed data, these generally perform quite well
            return Enum::GPU_BatchUnit_Fan;
        } else if (weights.size(0) > 8'192 && weights.dtype() == torch::kFloat32) {
            // If the data is non-transposed, and we have enough output units, we can use a FanBatch kernel
            // that can do some data-reuse inside a thread
            return can_vec ? Enum::GPU_Unit_FanBatch_Vector : Enum::GPU_Unit_FanBatch_Scalar;
        } else {
            // otherwise, we chose this kernel to ensure we actually make use of all cuda cores.
            return Enum::GPU_UnitBatch_Fan;
        }
    }

    static Tensor dispatch(
            const Tensor& features,
            const Tensor& weights,
            const Tensor& locations,
            const OptTensor& bias_opt,
            bool transposed,
            std::int64_t strategy_id) {
        xck::ForwardImplementations strategy;
        if (strategy_id == -1) {
            strategy = select_strategy(weights, transposed);
        } else {
            strategy = static_cast<xck::ForwardImplementations>(strategy_id);
        }

        auto dispatch_dtype = [&](auto transposed) {
            if (locations.dtype() == torch::kInt32 && features.dtype() == torch::kFloat32) {
                return run<float, std::int32_t, transposed.value>(strategy, features, weights, locations, bias_opt);
            } else if (locations.dtype() == torch::kInt16 && features.dtype() == torch::kFloat32) {
                return run<float, std::uint16_t, transposed.value>(strategy, features, weights, locations, bias_opt);
            } else if (locations.dtype() == torch::kInt32 && features.dtype() == torch::kFloat16) {
                return run<half, std::int32_t, transposed.value>(strategy, features, weights, locations, bias_opt);
            } else if (locations.dtype() == torch::kInt16 && features.dtype() == torch::kFloat16) {
                return run<half, std::uint16_t, transposed.value>(strategy, features, weights, locations, bias_opt);
            } else {
                TORCH_CHECK_TYPE(false, "Unsupported combination of input types")
            }
        };

        if (transposed) {
            return dispatch_dtype(xck::integral_v<true>);
        } else {
            return dispatch_dtype(xck::integral_v<false>);
        }
    }
};

struct FFIMeta {
    static Tensor forward(
            const Tensor& features,
            const Tensor& weights,
            const Tensor& locations,
            const OptTensor& bias_opt,
            bool transposed,
            std::int64_t strategy) {
        std::int64_t batch_size = transposed ? features.size(1) : features.size(0);
        std::int64_t output_size = weights.size(0);
        return allocate_output(features, batch_size, output_size);
    }

    static Tensor backward_ftr(
            const Tensor& features,
            const Tensor& weights,
            const Tensor& locations,
            const Tensor& output_gradient,
            bool transposed,
            std::int64_t strategy) {

        Tensor input_gradient = allocate_output(features, features.size(0), features.size(1));
        return input_gradient;
    }

    static Tensor backward_wgt(
            const Tensor& features,
            const Tensor& weights,
            const Tensor& locations,
            const Tensor& output_gradient,
            bool transposed,
            std::int64_t strategy) {

        Tensor weight_gradient = allocate_output(weights, weights.size(0), weights.size(1));
        return weight_gradient;
    }
};

template<xck::EDeviceType Device>
struct SparseBackwardOp {
    struct TagWgt {};

    template<class Float, class Int, bool Transposed>
    static Tensor run(
            xck::BackwardFtrImplementations strategy,
            const Tensor& features,
            const Tensor& weights,
            const Tensor& locations,
            const Tensor& output_gradient) {

        using OP = xck::FFIFeatureGradOp<Float, Int, Transposed>;
        torch_device_t<Device> device{};

        Tensor input_gradient = allocate_output(features, features.size(0), features.size(1));
        Tensor weight_gradient = allocate_output(weights, weights.size(0), weights.size(1));

        auto weights_mat = to_matrix<Float>(weights);
        auto locations_mat = to_matrix<Int>(locations);
        auto output_grad_mat = to_matrix<Float>(output_gradient);
        auto input_grad_mat = to_matrix<Float>(input_gradient);

        OP::call(device, strategy, locations_mat, weights_mat, output_grad_mat, input_grad_mat);

        return input_gradient;
    }


    template<class Float, class Int, bool Transposed>
    static Tensor run(
            xck::BackwardWgtImplementations strategy,
            const Tensor& features,
            const Tensor& weights,
            const Tensor& locations,
            const Tensor& output_gradient) {

        using OP = xck::FFIWeightGradOp<Float, Int, Transposed>;
        torch_device_t<Device> device{};

        Tensor weight_gradient = allocate_output(weights, weights.size(0), weights.size(1));

        auto input_mat = to_matrix<Float>(features);
        auto locations_mat = to_matrix<Int>(locations);
        auto output_grad_mat = to_matrix<Float>(output_gradient);
        auto weight_grad_mat = to_matrix<Float>(weight_gradient);

        OP::call(device, strategy, input_mat, locations_mat, output_grad_mat, weight_grad_mat);

        return weight_gradient;
    }

    template<class T>
    static Tensor dispatch(
            T strategy,
            const Tensor& features,
            const Tensor& weights,
            const Tensor& locations,
            const Tensor& output_gradient,
            bool transposed) {

        CHECK_DEVICE(features, Device)
        CHECK_DEVICE(weights, Device)
        CHECK_DEVICE(locations, Device)
        CHECK_DEVICE(output_gradient, Device)

        auto dispatch_dtype = [&](auto transposed) {
            if (locations.dtype() == torch::kInt32 && features.dtype() == torch::kFloat32) {
                return run<float, std::int32_t, transposed.value>(strategy, features, weights, locations, output_gradient);
            } else if (locations.dtype() == torch::kInt16 && features.dtype() == torch::kFloat32) {
                return run<float, std::uint16_t, transposed.value>(strategy, features, weights, locations, output_gradient);
            } else if (locations.dtype() == torch::kInt32 && features.dtype() == torch::kHalf) {
                return run<half, std::int32_t, transposed.value>(strategy, features, weights, locations, output_gradient);
            } else if (locations.dtype() == torch::kInt16 && features.dtype() == torch::kHalf) {
                return run<half, std::uint16_t, transposed.value>(strategy, features, weights, locations, output_gradient);
            } else {
                TORCH_CHECK_TYPE(false, "locations must be int32 or int16")
            }
        };

        if (transposed) {
            return dispatch_dtype(xck::integral_v<true>);
        } else {
            return dispatch_dtype(xck::integral_v<false>);
        }
    }

    static xck::BackwardFtrImplementations select_strategy_ftr(const Tensor& weights, bool transposed) {
        using Enum = xck::BackwardFtrImplementations;
        bool can_vec = weights.size(0) % 4 == 0;
        if constexpr (Device == xck::EDeviceType::Cpu) {
            return Enum::CPU;
        } else if (transposed) {
            return can_vec ? Enum::GPU_BatchUnit_Fan_Vector : Enum::GPU_BatchUnit_Fan_Scalar;
        } else {
            return can_vec ? Enum::GPU_UnitFan_Batch_Vector : Enum::GPU_UnitFan_Batch_Scalar;
        }
    }

    static xck::BackwardWgtImplementations select_strategy_wgt(const Tensor& weights, bool transposed) {
        using Enum = xck::BackwardWgtImplementations;
        bool can_vec = weights.size(0) % 4 == 0;
        if constexpr (Device == xck::EDeviceType::Cpu) {
            return Enum::CPU;
        } else if (transposed) {
            return Enum::GPU_FanUnit_Batch_Warp;
        } else {
            return can_vec ? Enum::GPU_UnitFan_Batch_Vector : Enum::GPU_UnitFan_Batch_Scalar;
        }
    }


    static auto dispatch_ftr(
            const Tensor& input,
            const Tensor& weights,
            const Tensor& locations,
            const Tensor& output_gradient,
            bool transposed,
            std::int64_t strategy_id) {
        xck::BackwardFtrImplementations strategy;
        if (strategy_id == -1) {
            strategy = select_strategy_ftr(weights, transposed);
        } else {
            strategy = static_cast<xck::BackwardFtrImplementations>(strategy_id);
        }
        return dispatch(strategy, input, weights, locations, output_gradient, transposed);
    }

    static auto dispatch_wgt(
            const Tensor& input,
            const Tensor& weights,
            const Tensor& locations,
            const Tensor& output_gradient,
            bool transposed,
            std::int64_t strategy_id) {
        xck::BackwardWgtImplementations strategy;
        if (strategy_id == -1) {
            strategy = select_strategy_wgt(weights, transposed);
        } else {
            strategy = static_cast<xck::BackwardWgtImplementations>(strategy_id);
        }
        return dispatch(strategy, input, weights, locations, output_gradient, transposed);
    }
};

template<class Float, class Int, xck::EDeviceType Device, class Functor>
struct SparseLossForward {
    static Tensor run(
            Tensor scores,
            Tensor labels) {

        using OP = xck::PointWiseDenseSparseToDenseOp<Float, Int, Functor>;

        CHECK_DEVICE(scores, Device)
        CHECK_DEVICE(labels, Device)

        Tensor output = allocate_output(scores, scores.size(0), scores.size(1));

        torch_device_t<Device> device{};

        xck::DenseSparseToDenseImplementations imp;
        if constexpr (Device == xck::EDeviceType::Cpu) {
            imp = xck::DenseSparseToDenseImplementations::CPU;
        } else if constexpr (Device == xck::EDeviceType::Cuda) {
            imp = xck::DenseSparseToDenseImplementations::GPU;
        } else {
            gsl_FailFast();
        }

        OP::call(device, imp, Functor{}, to_matrix<Float>(scores), to_matrix<Int>(labels), to_matrix<Float>(output));

        return output;
    }
};

template<class Float, class Int, xck::EDeviceType Device, class Functor>
struct SparseLossBackward {
    static Tensor run(
            Tensor scores,
            Tensor labels,
            Tensor back_grad) {
        using OP = xck::PointWiseDenseSparseToDenseGradOp<Float, Int, Functor>;

        CHECK_DEVICE(scores, Device)
        CHECK_DEVICE(labels, Device)
        CHECK_DEVICE(back_grad, Device)

        Tensor scores_grad = allocate_output(scores, scores.size(0), scores.size(1));

        torch_device_t<Device> device{};

        xck::DenseSparseToDenseImplementations imp;
        if constexpr (Device == xck::EDeviceType::Cpu) {
            imp = xck::DenseSparseToDenseImplementations::CPU;
        } else if constexpr (Device == xck::EDeviceType::Cuda) {
            imp = xck::DenseSparseToDenseImplementations::GPU;
        } else {
            gsl_FailFast();
        }

        OP::call(device, imp, Functor{}, to_matrix<Float>(scores), to_matrix<Int>(labels), to_matrix<Float>(back_grad),
                 to_matrix<Float>(scores_grad));

        return scores_grad;
    }
};

// dispatchers; https://pytorch.org/tutorials/advanced/dispatcher.html#adding-autograd-support
Tensor ffi_forward(const Tensor& features, const Tensor& weights, const Tensor& locations,
                   const OptTensor& bias, bool transpose, std::int64_t strategy = -1) {
    static auto op = torch::Dispatcher::singleton()
                             .findSchemaOrThrow("torch_sparse_ops::ffi_forward", "")
                             .typed<decltype(ffi_forward)>();
    return op.call(features, weights, locations, bias, transpose, strategy);
}

Tensor ffi_backward_ftr(const Tensor& features, const Tensor& weights,
                        const Tensor& locations, const Tensor& output_gradient,
                        bool transpose, std::int64_t strategy = -1) {
    static auto op = torch::Dispatcher::singleton()
                             .findSchemaOrThrow("torch_sparse_ops::ffi_backward_ftr", "")
                             .typed<decltype(ffi_backward_ftr)>();
    return op.call(features, weights, locations, output_gradient, transpose, strategy);
}

Tensor ffi_backward_wgt(const Tensor& features, const Tensor& weights,
                        const Tensor& locations, const Tensor& output_gradient,
                        bool transpose, std::int64_t strategy = -1) {
    static auto op = torch::Dispatcher::singleton()
                             .findSchemaOrThrow("torch_sparse_ops::ffi_backward_wgt", "")
                             .typed<decltype(ffi_backward_wgt)>();
    return op.call(features, weights, locations, output_gradient, transpose, strategy);
}

Tensor ffi_forward_autocast(const Tensor& features, const Tensor& weights, const Tensor& locations,
                            const OptTensor& bias, bool transpose, std::int64_t strategy = -1) {
    c10::impl::ExcludeDispatchKeyGuard no_autocast(c10::DispatchKey::Autocast);
    return ffi_forward(at::autocast::cached_cast(at::kHalf, features),
                       at::autocast::cached_cast(at::kHalf, weights),
                       locations,
                       at::autocast::cached_cast(at::kHalf, bias),
                       transpose,
                       strategy);
}

Tensor ffi_backward_ftr_autocast(const Tensor& features, const Tensor& weights,
                                 const Tensor& locations, const Tensor& output_gradient,
                                 bool transpose, std::int64_t strategy = -1) {
    c10::impl::ExcludeDispatchKeyGuard no_autocast(c10::DispatchKey::Autocast);
    return ffi_backward_ftr(at::autocast::cached_cast(at::kFloat, features),
                            at::autocast::cached_cast(at::kFloat, weights),
                            locations,
                            at::autocast::cached_cast(at::kFloat, output_gradient),
                            transpose,
                            strategy);
}

Tensor ffi_backward_wgt_autocast(const Tensor& features, const Tensor& weights,
                                 const Tensor& locations, const Tensor& output_gradient,
                                 bool transpose, std::int64_t strategy = -1) {
    c10::impl::ExcludeDispatchKeyGuard no_autocast(c10::DispatchKey::Autocast);
    return ffi_backward_wgt(at::autocast::cached_cast(at::kHalf, features),
                            at::autocast::cached_cast(at::kHalf, weights),
                            locations,
                            at::autocast::cached_cast(at::kHalf, output_gradient),
                            transpose,
                            strategy);
}

// https://pytorch.org/tutorials/advanced/dispatcher.html
// https://github.com/pytorch/pytorch/blob/main/aten/src/ATen/native/README.md
TORCH_LIBRARY(torch_sparse_ops, m) {
    std::vector<at::Tag> tags;
#if TORCH_VERSION_MINOR >= 3
    tags.push_back(at::Tag::needs_fixed_stride_order);
#endif
    m.def("ffi_forward(Tensor features, Tensor weights, Tensor locations, Tensor? bias, bool transposed, int strategy=-1) -> Tensor", tags, torch::_RegisterOrVerify::REGISTER);
    m.def("ffi_backward_ftr(Tensor features, Tensor weights, Tensor locations, Tensor out_grad, bool transposed, int strategy=-1) -> Tensor", tags, torch::_RegisterOrVerify::REGISTER);
    m.def("ffi_backward_wgt(Tensor features, Tensor weights, Tensor locations, Tensor out_grad, bool transposed, int strategy=-1) -> Tensor", tags, torch::_RegisterOrVerify::REGISTER);

    m.def("squared_hinge_forward(Tensor scores, Tensor labels) -> Tensor", tags, torch::_RegisterOrVerify::REGISTER);
    m.def("squared_hinge_backward(Tensor scores, Tensor labels, Tensor back_grad) -> Tensor", tags, torch::_RegisterOrVerify::REGISTER);
}

TORCH_LIBRARY_IMPL(torch_sparse_ops, CPU, m) {
    m.impl("ffi_forward", &SparseForwardOp<xck::EDeviceType::Cpu>::dispatch);
    m.impl("ffi_backward_ftr", &SparseBackwardOp<xck::EDeviceType::Cpu>::dispatch_ftr);
    m.impl("ffi_backward_wgt", &SparseBackwardOp<xck::EDeviceType::Cpu>::dispatch_wgt);

    m.impl("squared_hinge_forward", &SparseLossForward<float, std::int32_t, xck::EDeviceType::Cpu, xck::SquaredHingeFunctor<float>>::run);
    m.impl("squared_hinge_backward", &SparseLossBackward<float, std::int32_t, xck::EDeviceType::Cpu, xck::SquaredHingeFunctor<float>>::run);
}

TORCH_LIBRARY_IMPL(torch_sparse_ops, CUDA, m) {
    m.impl("ffi_forward", &SparseForwardOp<xck::EDeviceType::Cuda>::dispatch);
    m.impl("ffi_backward_ftr", &SparseBackwardOp<xck::EDeviceType::Cuda>::dispatch_ftr);
    m.impl("ffi_backward_wgt", &SparseBackwardOp<xck::EDeviceType::Cuda>::dispatch_wgt);

    m.impl("squared_hinge_forward", &SparseLossForward<float, std::int32_t, xck::EDeviceType::Cuda, xck::SquaredHingeFunctor<float>>::run);
    m.impl("squared_hinge_backward", &SparseLossBackward<float, std::int32_t, xck::EDeviceType::Cuda, xck::SquaredHingeFunctor<float>>::run);
}

TORCH_LIBRARY_IMPL(torch_sparse_ops, Meta, m) {
    m.impl("ffi_forward", &FFIMeta::forward);
    m.impl("ffi_backward_ftr", &FFIMeta::backward_ftr);
    m.impl("ffi_backward_wgt", &FFIMeta::backward_wgt);
}

TORCH_LIBRARY_IMPL(torch_sparse_ops, Autocast, m) {
    m.impl("ffi_forward", ffi_forward_autocast);
    m.impl("ffi_backward_ftr", ffi_backward_ftr_autocast);
    m.impl("ffi_backward_wgt", ffi_backward_wgt_autocast);
}
